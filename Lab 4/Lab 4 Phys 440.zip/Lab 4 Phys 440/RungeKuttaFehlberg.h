/*
 *  RungeKuttaFehlberg.h
 *  Lab 4 Phys 440
 *
 *  Created by Matthew Beck on 3/19/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

