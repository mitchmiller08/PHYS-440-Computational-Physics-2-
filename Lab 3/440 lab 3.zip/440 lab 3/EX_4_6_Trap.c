/*
 *  EX_4_6_Trap.c
 *  440 lab 3
 *
 *  Created by Matthew Beck on 2/23/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#include "EX_4_6_Trap.h"

